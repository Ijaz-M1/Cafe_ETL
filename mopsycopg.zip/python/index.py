import json
import psycopg2
import boto3


client=boto3.client('s3')
def lambda_handler(event, context):
    # ssm_client = boto3.client('ssm', region_name='eu-west-1')
    session = boto3.Session(profile_name='generation')
    ssm_client = session.client('ssm', region_name='eu-west-1')
    # Get the SSM Param from AWS and turn it into JSON
    # Don't log the password!
    def get_ssm_param(param_name):
        print(f'get_ssm_param: getting param_name={param_name}')
        parameter_details = ssm_client.get_parameter(Name=param_name)
        redshift_details = json.loads(parameter_details['Parameter']['Value'])
        host = redshift_details['host']
        user = redshift_details['user']
        db = redshift_details['database-name']
        print(f'get_ssm_param loaded for db={db}, user={user}, host={host}')
        return redshift_details
    redshift_login_details = get_ssm_param('data_xcelerator_redshift_settings')
    print(redshift_login_details)
    def setup_db_connection():
        connection = psycopg2.connect(
            host='redshiftcluster-h0ppssmszukx.cyedtoskxrzl.eu-west-1.redshift.amazonaws.com:5439/dev',
            # host=redshift_login_details['host'],
            database=redshift_login_details['database-name'],
            user=redshift_login_details['user'],
            port=5439,
            password=redshift_login_details['password'],
        )
        return connection
    conn=setup_db_connection()
    cursor=conn.cursor()
    cursor.execute('''
                create table customers(
    customer_id SERIAL PRIMARY KEY,
    location VARCHAR(255) NOT NULL
    );''')
    conn.commit()
    cursor.execute('insert into customer(customer_id,location) values (1,"bradford")')
    conn.commit()

    cursor.execute('select * from customers')

    for data in cursor.fetchall():
        print(data)
